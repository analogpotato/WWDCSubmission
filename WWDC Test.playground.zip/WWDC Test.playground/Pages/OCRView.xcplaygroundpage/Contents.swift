import UIKit
import PlaygroundSupport
import VisionKit


 class OCRView:UIViewController {
    
   
     override func viewDidLoad() {
        super.viewDidLoad()

    }
      
    
    
}


let vc = OCRView()
vc.preferredContentSize = CGSize.init(width: 768,height: 1024)
PlaygroundPage.current.liveView = vc
PlaygroundPage.current.needsIndefiniteExecution = true
