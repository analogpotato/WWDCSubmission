import UIKit
import PlaygroundSupport
import VisionKit


 class TextSearchView : UIViewController, UITextFieldDelegate {

    var label : UILabel!
    var textField : UITextField!
    var button: UIButton!
    
    var savedSearchTerm = ""

    let imageView = ScanImageView (frame: .zero)
    

    
     override func loadView() {

        
        // UI

        let view = UIView()
        view.backgroundColor = .white
        
        
        
     
        button = UIButton(type: .system)
        button.setTitle("Search", for: .normal)
        button.tintColor = .white
        button.backgroundColor = UIColor.systemIndigo
        button.addTarget(self, action: #selector(saveButtonPressed), for: .touchUpInside)
        


        
        view.addSubview(button)
        
        
        textField = UITextField()
        textField.borderStyle = .roundedRect
        textField.text = "Type Here"
        view.addSubview(textField)

        label = UILabel()
        label.text = "What would you like to search for?"
        view.addSubview(label)
        
        
        view.addSubview(imageView)

        self.view = view


        // Layout

        textField.translatesAutoresizingMaskIntoConstraints = false
        label.translatesAutoresizingMaskIntoConstraints = false
        button.translatesAutoresizingMaskIntoConstraints = false
        
        let margins = view.layoutMarginsGuide
        NSLayoutConstraint.activate([
            textField.topAnchor.constraint(equalTo: margins.topAnchor, constant: 20),
            textField.leadingAnchor.constraint(equalTo: margins.leadingAnchor),
            textField.trailingAnchor.constraint(equalTo: margins.trailingAnchor),
            
            label.leadingAnchor.constraint(equalTo: textField.leadingAnchor),
            label.topAnchor.constraint(equalTo: textField.bottomAnchor, constant: 10),
            
            button.leadingAnchor.constraint(equalTo: label.trailingAnchor, constant: 20),
            button.firstBaselineAnchor.constraint(equalTo: label.firstBaselineAnchor),
            
            imageView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
            imageView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: 10),
            imageView.bottomAnchor.constraint(equalTo: button.topAnchor, constant: 500)
        ])

        // Events

        textField.addTarget(self, action: #selector(updateLabel), for: UIControl.Event.editingChanged)

        updateLabel()
    }
    



    @objc func updateLabel() {
        
        print(textField.text!)
    }
    
    @objc func saveButtonPressed() {
        self.savedSearchTerm = textField.text!
//        print(savedSearchTerm)
        print("Button Pressed, the word is \(savedSearchTerm)")
        
        let scanVC = VNDocumentCameraViewController()
        scanVC.delegate = self
        present(scanVC, animated: true)
        
    }
    
    
    
    
    
    
}


class ScanImageView: UIImageView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        configure()
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    private func configure() {
        translatesAutoresizingMaskIntoConstraints = false
        layer.cornerRadius = 7.0
        layer.borderWidth = 1.0
        layer.borderColor = UIColor.systemIndigo.cgColor
        backgroundColor = UIColor.init(white: 1.0, alpha: 0.1)
        clipsToBounds = true
    }
}



extension TextSearchView: VNDocumentCameraViewControllerDelegate {
     func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
            guard scan.pageCount >= 1 else {
                    controller.dismiss(animated: true)
                    return
                }
                //Place code in here to move/do something
            
        imageView.image = scan.imageOfPage(at: 0)
        
                controller.dismiss(animated: true)
            }
            
     func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFailWithError error: Error) {
                //Handle properly error
                controller.dismiss(animated: true)
            }
            
     func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
                controller.dismiss(animated: true)
            }
    
}

let vc = TextSearchView()
vc.preferredContentSize = CGSize.init(width: 768,height: 1024)
PlaygroundPage.current.liveView = vc
